import 'typeface-roboto-condensed';
import './App.css';
import Home from './components/Dashboard/home';
function App() {
  return (
    <Home/>
  );
}

export default App;
