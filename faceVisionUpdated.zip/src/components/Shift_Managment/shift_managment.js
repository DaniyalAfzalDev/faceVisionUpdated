import React from "react";

const Shift_Management = () => {
    return (
        <div>
            <h1>Shift Management Page</h1>
        </div>
    );
};

export default Shift_Management;
