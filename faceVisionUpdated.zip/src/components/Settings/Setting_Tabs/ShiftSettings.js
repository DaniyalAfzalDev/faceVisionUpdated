import React from 'react'

const ShiftSettings = () => {
  return (
    <div>
      <h2>ShiftSettings</h2>
    </div>
  )
}

export default ShiftSettings
