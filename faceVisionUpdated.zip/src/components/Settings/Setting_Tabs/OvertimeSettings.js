import React from 'react'

const OvertimeSettings = () => {
  return (
    <div>
      <h2>OvertimeSettings</h2>
    </div>
  )
}

export default OvertimeSettings
