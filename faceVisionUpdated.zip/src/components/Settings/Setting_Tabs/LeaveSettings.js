import React from 'react'

const LeaveSettings = () => {
  return (
    <div>
      <h2>LeaveSettings</h2>
    </div>
  )
}

export default LeaveSettings
