import React from "react";

const Leaves = () => {
    return (
        <div>
            <h1>Leaves Page</h1>
        </div>
    );
};

export default Leaves;
