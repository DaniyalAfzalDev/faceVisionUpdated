import React from "react";

const Blocklist = () => {
    return (
        <div>
            <h1>Blocklist Page</h1>
        </div>
    );
};

export default Blocklist;
