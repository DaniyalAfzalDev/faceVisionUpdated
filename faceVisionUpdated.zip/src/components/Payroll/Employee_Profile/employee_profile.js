import React from "react";

const Employee_Profile = () => {
    return (
        <div>
            <h1>Employee_Profile Page</h1>
        </div>
    );
};

export default Employee_Profile;
