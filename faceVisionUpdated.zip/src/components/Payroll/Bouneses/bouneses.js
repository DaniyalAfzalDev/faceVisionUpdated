import React from "react";

const Bonuses = () => {
    return (
        <div>
            <h1>Bonuses Page</h1>
        </div>
    );
};

export default Bonuses;
