import React from "react";

const Payroll_profile = () => {
    return (
        <div>
            <h1>Payroll_profile Page</h1>
        </div>
    );
};

export default Payroll_profile;
